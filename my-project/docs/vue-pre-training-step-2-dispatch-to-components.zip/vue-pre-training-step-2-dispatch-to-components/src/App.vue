<template>
  <HomePage />
</template>

<script>
import HomePage from '@/views/HomePage';

export default {
  name: 'App',
  components: {
    HomePage,
  }
}
</script>

<style></style>