<template>
  <div class="p-6 bg-blue-500 text-white">
    <p>HeaderNavbar Menu</p>
    <!-- Contenu de votre HeaderNavbar -->
  </div>
</template>

<script>
export default {
  name: 'HeaderNavbar',
}
</script>

<style scoped>
/* Styles spécifiques à HeaderNavbar ici */
</style>