<template>
  <!-- En-tête (HeroSection) -->
  <div class="p-6 bg-green-500 text-white flex-grow">
    <p>En-tête (HeroSection)</p>
    <!-- Contenu de votre En-tête -->
  </div>
</template>

<script>
export default {
  name: 'HeroSection',
}
</script>

<style scoped>
/* Styles spécifiques à HeroSection ici */
</style>