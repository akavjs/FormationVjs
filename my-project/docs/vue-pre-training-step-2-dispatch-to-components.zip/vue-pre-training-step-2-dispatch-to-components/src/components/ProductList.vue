<template>
  <!-- Liste de produits (ProductList) -->
    <div class="p-6 bg-red-500 text-white flex-grow">
      <p>Liste de produits</p>
      <!-- Contenu de votre liste de produits -->
    </div>
</template>

<script>
export default {
  name: 'ProductList',
}
</script>

<style scoped>
/* Styles spécifiques à ProductList ici */
</style>