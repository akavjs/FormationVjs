export const mainDB = {
    heroBackgroundImage: 'https://via.placeholder.com/1600x900',
    headerNavLinks: [
      { name: 'Accueil', href: '/', current: true },
      { name: 'À propos', href: '/about', current: false },
      { name: 'Utilisateurs', href: '/user', current: false },
      { name: 'Produits', href: '/produits', current: false },
    ]
  };
  