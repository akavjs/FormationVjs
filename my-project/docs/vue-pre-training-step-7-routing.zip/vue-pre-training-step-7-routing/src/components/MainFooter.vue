<template>
  <!-- Pied de page (MainFooter) -->
  <div class="p-6 bg-yellow-500 text-white mt-auto">
    <p>Pied de page</p>
    <!-- Placez ici le contenu de votre MainFooter -->
  </div>
</template>

<script>
export default {
  name: 'MainFooter',
}
</script>

<style scoped>
/* Styles spécifiques à MainFooter ici */
</style>