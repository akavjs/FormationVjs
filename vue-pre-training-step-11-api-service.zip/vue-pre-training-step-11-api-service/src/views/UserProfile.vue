<template>
    <div>
        <h1>Profil de l'Utilisateur</h1>
        <!-- Afficher les informations de l'utilisateur ici -->
    </div>
</template>
  
<script>
export default {
    name: 'UserProfile',
    // ... autres options ...
}
</script>